GarfieldAmp v2.0

The world's most popular and favorite cat graces your screen 
with his trademark smirk. GarfieldAmp has Garfield mugging
with his best bud, Pookie. Don't forget his favorite food dish 
zooming across the table top as well! Now Winamp 2.0+ compatible!
 
More of my skins can be found on my web page at:
	http://members.xoom.com/dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@hotmail.com
5/12/98
11/24/98: added Playlist and Equalizer customization
          added tabletop under position bar